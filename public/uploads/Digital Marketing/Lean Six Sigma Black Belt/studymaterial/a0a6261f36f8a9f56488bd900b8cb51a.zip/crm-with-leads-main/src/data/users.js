const users = [
{"_id":"608af43731f85fb848ae1077","login":"admin","password":"admin","name":["Александр ","Невский"],"role":"admin","groups":["admins"],"avatar":"https://material-ui.com/static/images/avatar/1.jpg","created":"1614704400000"},
{"_id":"608af5b931f85fb848ae1078","login":"rop","password":"rop","name":["Ольга ","Петровна"],"role":"rop","groups":["rops","sales"],"avatar":"https://material-ui.com/static/images/avatar/4.jpg","created":"1614704400000"},
{"_id":"608af5e931f85fb848ae1079","login":"manager1","password":"111","name":["Николай ","Иванов"],"role":"manager","groups":["sales"],"avatar":"https://material-ui.com/static/images/avatar/2.jpg","created":"1614704400000"},
{"_id":"608af71831f85fb848ae107a","login":"manager2","password":"222","name":["Некрасова ","Елена"],"role":"manager","groups":["sales"],"avatar":"https://material-ui.com/static/images/avatar/3.jpg","created":"1614704400000"}
];

export default users;