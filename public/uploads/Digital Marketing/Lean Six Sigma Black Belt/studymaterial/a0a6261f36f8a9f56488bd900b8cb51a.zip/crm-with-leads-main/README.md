# CRM system frontend prototype 
# Modules
Sales manager module. Dashboard, Tasks (Kanban), Clients, Contacts, Leads, Calendar. 
# Frontend
React/React-router//Redux/TypeScript/Material-UI/dx-react-chart/dx-react-grid/dx-react-scheduler
